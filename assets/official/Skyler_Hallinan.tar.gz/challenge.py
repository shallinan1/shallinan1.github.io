"""
Skyler Hallinan
9/5/2020
Noah's ARK Challenge Code
"""

import pandas as pd
from nltk.classify import NaiveBayesClassifier
from nltk import ngrams
import csv
import random
from random import choice
import re

"""
Part 1: Creating an English sentence classifier using ngrams
"""
#%% Import training data (label English as "Original", corrupted version as "Modified")
dfTrain = pd.read_csv("train.txt", delimiter = "\t", 
                 usecols=range(2),
                 header = None,
                 quoting=csv.QUOTE_NONE,
                 engine = "python")
dfTrain.columns = ["Original", "Modified"]
#%% Import test data
dfTest = pd.read_csv("test.rand.txt", delimiter = "\t", 
                 usecols=range(2),
                 header = None,
                 quoting=csv.QUOTE_NONE,
                 engine = "python")
dfTest.columns = ["Unknown1", "Unknown2"]
#%% Define function to generate ngram counts for a string
def create_ngrams(words, n = 1):
    ngram_vocab = ngrams(words, n)
    all_grams = dict([(ngram, True) for ngram in ngram_vocab])
    return all_grams

#%% Create ngrams with different n to calculate best n to use, using cross validation

"""
Trains a Naive Bayes Classifier with data from df_train using n-gram occurences 
as features for each sentence, where n = curN. Uses cvSize-fold cross validation
and prints the average accuracy of the classifier on the validation sets.
"""
def train_with_cv(cvSize, curN, df_train):
    # Calculate partition size for the cross-validation
    partitionSize = len(df_train)//cvSize
    
    # Create the ngrams for both English and corrupted sentences
    allGramsOriginal = df_train.Original.apply(create_ngrams, args = (curN, ))
    allGramsModified = df_train.Modified.apply(create_ngrams, args = (curN, ))
    
    pos_data = [tuple((x, "Original")) for x in allGramsOriginal]
    neg_data = [tuple((x, "Modified")) for x in allGramsModified]
    
    totalAccuracy = 0
    for c in range(cvSize):
        
        cvLowBound = partitionSize * c
        cvHighBound = cvLowBound + partitionSize
        
        # Partition into training and validation (test) sets
        trainData = pos_data[:cvLowBound] + pos_data[cvHighBound:] + \
            neg_data[:cvLowBound] + neg_data[cvHighBound:]
    
        posTest = pos_data[cvLowBound:cvHighBound]
        negTest = neg_data[cvLowBound:cvHighBound]
        
        # Set testData so that each pair of two indeces correspond to pairs of sentences
        testData = [None]*(len(posTest) + len(negTest))
        testData[::2] = posTest
        testData[1::2] = negTest
        
        classifier = NaiveBayesClassifier.train(trainData)
        count = 0
    
        # Calculate accuracy by assigining labels based on the highest probability 
        # of the label for the two sentences, then comparing to actual labels
        for i in range(0, len(testData),2):
            sent1 = testData[i][0];
            sent1Lab = testData[i][1];
            sent2 = testData[i+1][0];
            sent2Lab = testData[i+1][1];
    
            sent1Prob = classifier.prob_classify(sent1)
            sent2Prob = classifier.prob_classify(sent2)
            
            sent1Pred = "Modified"
            sent2Pred = "Original"
            
            if sent1Prob.prob("Modified") < sent2Prob.prob("Modified"):
                sent1Pred = "Original"
                sent2Pred = "Modified"
                
            if (sent1Pred == sent1Lab):
                count+=2
            
        accuracy = count/len(testData)

        print(accuracy)
        totalAccuracy += accuracy
    
    totalAccuracy /= cvSize
    print("avg is", totalAccuracy)

# Test out a variety of n values for the classification test (different ngrams)
for curN in range(1, 8):
    print(curN)
    train_with_cv(5, curN, dfTrain)
#%%  Train classifier with n = 6 (since this had the best classification accuracy)
curN = 6
allGramsOriginal = dfTrain.Original.apply(create_ngrams, args = (curN, ))
allGramsModified = dfTrain.Modified.apply(create_ngrams, args = (curN, ))

pos_data = [tuple((x, "Original")) for x in allGramsOriginal]
neg_data = [tuple((x, "Modified")) for x in allGramsModified]

trainData = pos_data + neg_data
classifier = NaiveBayesClassifier.train(trainData)

#%% Create ngrams on test, classify test sentences, and write to file
allGramsTest1 = dfTest.Unknown1.apply(create_ngrams, args = (curN,))
allGramsTest2 = dfTest.Unknown2.apply(create_ngrams, args = (curN,))

with open("part1.txt", "w+") as f:
    for i in range(len(allGramsTest1)):
          sent1 = allGramsTest1[i]
          sent2 = allGramsTest2[i]
    
          sent1Prob = classifier.prob_classify(sent1)
          sent2Prob = classifier.prob_classify(sent2)
        
          if sent1Prob.prob("Original") > sent2Prob.prob("Original"):
              f.write("A\n")
          else:
              f.write("B\n")
     
"""
Part 2: Creating my own corruptions
"""
#%% Define functions needed to corupt the string  

def lower(curString):
    return curString.lower()

def upper(curString):
    return curString.upper()

# Randomly adds symbol to a position in the string not at beginning or end
def random_add_in_string(curString, symbol):
    idx = random.randint(1, len(curString) - 1)
    return curString[:idx] + symbol + curString[idx:]

# Replaces first character of string with apostrophe
def add_apos(curString):
    return "'" + curString[1:]

# Randomly applies function to one instance of a match from "find" in the string
def modify_random(curString, find, func, *args):
    matches = list(re.finditer(find, curString))
    replace = choice(matches)
    modifyStr = replace.group()
    if args:
        middle = func(modifyStr, args[0])
    else:
        middle = func(modifyStr)
    return curString[:replace.start()] + middle + curString[replace.end():]

# Randomly replaces one instance of a match from "find" with replaceStr
def replace_random(curString, find, replaceStr):
    matches = list(re.finditer(find, curString))
    replace = choice(matches)
    return curString[:replace.start()] + replaceStr + curString[replace.end():]

# Generates a random puncutation symbol, excluding removeChar
def rand_punct(removeChar = None):
    punct = [".", "!", "...", "?", ",", "-"]
    if removeChar is not None:
        punct.remove(removeChar)
    idx = random.randint(0, len(punct) - 1)
    return punct[idx]

# Generates a random int in a range of low to high inclusive, excluding all numbers in exclude
def random_int_exclude(low, high, exclude):
    return choice([i for i in range(low,high+1) if i not in exclude])
    
#%% Defining large function
"""
Chooses and applies a random coruption to a string. If the chosen corruption is 
not valid, continues to choose a different coruption, until it successfully finds 
a valid one, then applies the coruption and returns the string.
"""
def corrupt(curString, badNums = []):
    # Case if the sentence somehow doesn't satisfy any of the other conditions
    if len(badNums) == 12:
        return random_add_in_string(curString, rand_punct())
    
    curPath = random_int_exclude(0, 11, badNums)
    
    if curPath == 0:
        if (len(re.findall(r'\b[a-z]\w{1,}', curString)) > 0):
            return modify_random(curString, r'\b[a-z]\w{1,}', random_add_in_string, " ")
    elif curPath == 1:
        if (len(re.findall(r'\b[a-z]\w{1,}', curString)) > 0):
            return modify_random(curString, r'\b[a-z]\w{1,}', random_add_in_string, "-")   
    elif curPath == 2:
        if (len(re.findall(r'\b[a-z]\w{1,}', curString)) > 0):
            return modify_random(curString, r'\b[a-z]\w{1,}', add_apos)
    elif curPath == 3:
        if (curString.count(":") > 0):
            return replace_random(curString, ":", ";")
    elif curPath == 4:
        if (curString.count(";") > 0):
            return replace_random(curString, ";", ":")
    elif curPath == 5:
        if (len(re.findall(r'\b[a-z]', curString)) > 0):
            return modify_random(curString, r'\b[a-z]', upper)
    elif curPath == 6:
        if (len(re.findall(r'\b[A-Z]', curString)) > 0):
            return modify_random(curString, r'\b[A-Z]', lower)
    elif curPath == 7:
        if (curString.count("!") > 0):
            return replace_random(curString, "!", rand_punct("!"))
    elif curPath == 8:
        if (curString.count("?") > 0):
            return replace_random(curString, "\\?", rand_punct("?"))
    elif curPath == 9:
        if (curString.count("...") > 0):
            return replace_random(curString, "...", rand_punct("..."))
    elif curPath == 10:
        if (curString.count(",") > 0):
            return replace_random(curString, ",", rand_punct(","))
    elif curPath == 11:
        if (curString.count("-") > 0):
            return replace_random(curString, "-", rand_punct("-"))
    return corrupt(curString, badNums + [curPath])
#%% Apply corruptions to data frame in new column
dfTrain["New"] = dfTrain.Original.apply(corrupt)
rowsEqual = dfTrain.Modified == dfTrain.New

# Check if any of coruptions are same as old coruptions. If there are any, generate
# new coruptions until none are the same.
print(rowsEqual[rowsEqual])
while (sum(rowsEqual) > 0):
    idxs = rowsEqual.index[rowsEqual]
    
    for i in idxs:
        dfTrain.New[i] = corrupt(dfTrain.Original[i])

    rowsEqual = dfTrain.Modified == dfTrain.New
print(rowsEqual[rowsEqual])   

#%% Drop old coruption column and save new dataframe as tsv
newDf = dfTrain.copy()
newDf = newDf.drop("Modified", axis = 1)
newDf.to_csv("part2.txt",sep = "\t", index = False, header = False, quoting=csv.QUOTE_NONE)

#%% Try loading in this data (with new modification)
dfMade = pd.read_csv("part2.txt", delimiter = "\t", 
                 usecols=range(2),
                 header = None,
                 quoting=csv.QUOTE_NONE,
                 engine = "python")
dfMade.columns = ["Original", "Modified"]

#%% Try training on it, and see what the accuracy is (using 6-mer), and 5-fold cv
train_with_cv(5, 6, dfMade)